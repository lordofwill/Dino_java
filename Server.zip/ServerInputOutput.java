package Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class ServerInputOutput implements Runnable{

	static boolean run=true;
	final int PlaverThreadNum = ServerExample.playerNum;

	@Override
	public void run() {
		try {
		OutputStream output = ServerExample.socket[PlaverThreadNum].getOutputStream();
		DataOutputStream Dos = new DataOutputStream(output);
		Dos.writeInt(PlaverThreadNum);	
		Dos.flush();
		output.flush();
		} catch (Exception e) {}
		
		if (ServerExample.playerNum==4) {
			
			try {
				Thread.sleep(5000);
			for(int i=0;i<ServerExample.playerNum;i++) {
				if (i != PlaverThreadNum) {
					OutputStream output = ServerExample.socket[i].getOutputStream();
					DataOutputStream Dos = new DataOutputStream(output);
					Dos.writeInt(PlaverThreadNum);	
					output.flush();

				}
			}
			} catch (Exception e) {}
			}
		
		
		while (run) {
			InputStream is;
			try {
				//				내 클라이언트에서 정보 입력받는부분
				is = ServerExample.socket[PlaverThreadNum].getInputStream();
				DataInputStream Dis = new DataInputStream(is);
				
				int DieJump = Dis.readInt();
					
				System.out.println(DieJump);
				//					내 클라이언트가 아닌 다른 클라이언트에 출력부분
				if (DieJump==20) {
				for(int i=0;i<ServerExample.playerNum;i++) {
					if (i != PlaverThreadNum) {
						OutputStream output = ServerExample.socket[i].getOutputStream();
						DataOutputStream Dos = new DataOutputStream(output);
						Dos.writeInt(PlaverThreadNum);	
						output.flush();

					}
				}
				}
				if (DieJump == 666) {
					for(int i=0;i<ServerExample.playerNum;i++) {
						if (i != PlaverThreadNum) {
							OutputStream output = ServerExample.socket[i].getOutputStream();
							DataOutputStream Dos = new DataOutputStream(output);
							Dos.writeInt(PlaverThreadNum+10);
							Dos.flush();
							output.flush();
						}
					}
				} 
			} catch (IOException e) {System.out.println(PlaverThreadNum+"번째 클라이언트가 나갔습니다.");return;}
		}
	}





	public static void stop() {run=false;}

}