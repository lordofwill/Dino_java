package Server;
import java.net.*;
import java.io.*;


public class ServerExample{

	public static Socket [] socket= new Socket[4];
	public static InetSocketAddress[] guest = new InetSocketAddress[4];
	public static Thread [] inout = new Thread[4];
	static int playerNum = 0;
	public static boolean run = true;
	
	public static void main(String[] args) throws IOException{

		ServerSocket serverSocket = null;
		
		try {
			serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress("10.10.21.127", 8080));
			 run = true;

			while(run ||  playerNum==4) {
				System.out.println("[연결 기다림]");
				socket[playerNum] = serverSocket.accept();
				guest[playerNum] = (InetSocketAddress) socket[playerNum].getRemoteSocketAddress();
				System.out.println("[연결 수락됨]" +guest[playerNum].getHostName());
				
				Runnable inOutput0 = new ServerInputOutput();
				inout[playerNum]= new Thread(inOutput0);
				
				inout[playerNum].start();
				playerNum++;
			}
					
		}
		catch(Exception e) { 
			e.printStackTrace();
		}
	}

}
