package dinoGame;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MainController extends Main implements Initializable{
	public static Stage connectDialog;

	@FXML private Button singleScene;
	@FXML private Button pvpScene;
	@FXML private Button recordScene;
	@FXML private Button aiScene;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		singleScene.setOnAction(event->handleSingleAction(event));   
		aiScene.setOnAction(event->handleAiAction(event));	
		pvpScene.setOnAction(event->handlePvpAction(event));		 
		recordScene.setOnAction(event->handleRecordAction(event));	   
	}
	
	public void handleSingleAction(ActionEvent event) {				  
		try {
			Parent single = FXMLLoader.load(getClass().getResource("SinglePlay.fxml"));
			Scene scene = new Scene(single);
			Stage primaryStage = (Stage) singleScene.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void handleAiAction(ActionEvent event) {				  
		try {
			Parent ai = FXMLLoader.load(getClass().getResource("AiModeTest.fxml"));
			Scene scene = new Scene(ai);
			Stage primaryStage = (Stage) aiScene.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void handlePvpAction(ActionEvent event) {			      
		try {
			try {
				socket = new Socket();
				System.out.println("연결요청");
				socket.connect(new InetSocketAddress("10.10.21.127",8080));
				System.out.println("연결성공");
				
				InputStream is = socket.getInputStream();
				DataInputStream dis = new DataInputStream(is);
				myNumber = dis.readInt();
				
				
				to = Integer.toString(myNumber);
				
				} catch(Exception e) {}
			
			Parent record = FXMLLoader.load(getClass().getResource("Pvp.fxml"));
			Scene scene = new Scene(record);
			Stage primaryStage = (Stage) recordScene.getScene().getWindow();
			primaryStage.setScene(scene);						
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void handleRecordAction(ActionEvent event) {			     
		try {
			Parent record = FXMLLoader.load(getClass().getResource("Record.fxml"));
			Scene scene = new Scene(record);
			Stage primaryStage = (Stage) recordScene.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

	
	
	

}
	