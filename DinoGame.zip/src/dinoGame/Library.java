package dinoGame;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class Library {
	public static String data = " ";
	public static boolean multiplayStart = false;
	
	public static void dataLoading() throws Exception{
		FileInputStream fis = new FileInputStream("C:/Users/user/Documents/Eclipse/Dino/data/record.txt");
		Reader reader = new InputStreamReader(fis);
		int readByteNo;
		char[] readBytes = new char[3000];
		
		while((readByteNo=reader.read(readBytes))!=-1) {
			data = new String(readBytes, 0, readByteNo);
		}
		System.out.println("랭킹 데이터 읽기 성공");
		
	}
	
	
	
	
	
	
	
	
	

}
