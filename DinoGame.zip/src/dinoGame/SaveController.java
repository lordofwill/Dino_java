package dinoGame;

import java.io.FileOutputStream;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class SaveController implements Initializable{
	@FXML private Button check;												
	@FXML private TextField name;			
	@FXML private Text finalScore;
	@FXML private Text checkComplete;
	@FXML private Text nameChecker;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {		
		name.setOnAction(event->handleNameAction(event));
		check.setOnMouseClicked(event->{try {handleCheckAction(event);} catch (Exception e) {e.printStackTrace();}
		});
		finalScore.setText(Integer.toString(SingleController.reco));
	}

	public void handleNameAction(ActionEvent event) {						
		
	}
	
	public void handleCheckAction(MouseEvent event) throws Exception {
		FileOutputStream fos = new FileOutputStream("C:/Users/user/Documents/Eclipse/Dino/data/record.txt",true);
		if(name.getText().length()>=5) {
			nameChecker.setOpacity(0.7);
		}else {
		String saveName = "-"+name.getText()+"-"+finalScore.getText();								
		byte[] bytes = new byte[100];
		bytes = saveName.getBytes("UTF-8");
		fos.write(bytes);
		fos.flush();fos.close();
	

			

		System.out.println(name.getText()+" 데이터 저장됨.");
		SingleController.dialog.close();}

	}
}
