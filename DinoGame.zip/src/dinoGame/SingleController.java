package dinoGame;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class SingleController implements Initializable {

	@FXML private ImageView land0;
	@FXML private ImageView land1;
	@FXML private ImageView land2;
	@FXML private ImageView land3;
	@FXML private ImageView land4;
	@FXML private ImageView land5;
	@FXML private ImageView land6;
	@FXML private ImageView character;
	@FXML private ImageView cact;
	@FXML private TextField control;
	@FXML private Text score;
	@FXML private ImageView back;
	@FXML private ImageView save;
	@FXML private ImageView gameOver;
	@FXML private Text help1;
	@FXML private Text help2;
	public static int reco;
	int charrun=0;
	int speed;
	int cactRan;
	boolean start=true;
	boolean stop_all = true;
	boolean jump = true;
	String [] charimg = {"../data/main-character1.png","../data/main-character2.png","../data/main-character3.png","../data/main-character4.png"};
	String [] landimg = {"../data/land2.png","../data/land1.png","../data/land3.png"};
	String [] cac = {"", "../data/cactus1.png", "../data/cactus2.png"};
	static Stage dialog;













	// 초기화시 시작되는 부분

	@Override	
	public void initialize(URL location, ResourceBundle resources) {
		back.setOnMouseClicked(event->handleBackAction(event));
		save.setOnMouseClicked(event->{try {handleSaveAction(event);} catch (Exception e) {}});
		character.setImage(new Image(getClass().getResource(charimg[1]).toString()));
		control.setTranslateY(-30);
		land0.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land1.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land2.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land3.setImage(new Image(getClass().getResource("../data/land2.png").toString()));
		land4.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land5.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land6.setImage(new Image(getClass().getResource("../data/land1.png").toString()));

		land0.setTranslateX(71);
		land1.setTranslateX(71);
		land2.setTranslateX(71);
		land3.setTranslateX(71);
		land4.setTranslateX(71);
		land5.setTranslateX(71);
		land6.setTranslateX(71);

		// 여기까지 기본 버튼들과 컨트롤패널, 땅을 깔아줌





		// 여기서부터 공룡을 클릭했을때의 이벤트 처리 setOnMouseClicked

		character.setOnMouseClicked(new EventHandler<Event>(){
			@Override
			public void handle(Event event) {
				if (start) {
					//land의 움직임
					imgMove(land0, 0);
					imgMove(land1, 1);
					imgMove(land2, 2);
					imgMove(land3, 3);
					imgMove(land4, 4);
					imgMove(land5, 5);
					imgMove(land6, 6);





					CharRun(character);		// 메인캐릭터의 달리는부분(점프포함) 
					Thread t2 = new Thread(()->cactMove());;	// 선인장의 움직임부분 스레드
					Thread t3 = new Thread(()->score());;		// 스코어 올라가는 스레드
					Thread t4 = new Thread(()->collision());;	// 충돌시 사망하는 판정 스레드
					t2.setDaemon(true);
					t3.setDaemon(true);
					t4.setDaemon(true);
					t2.start();
					t3.start();
					t4.start()
					;	
				}start=false;
				help1.setOpacity(0);
				help2.setOpacity(0);
			}

		});





		control.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (jump) {
					if (event.getCode()==KeyCode.UP||event.getCode()==KeyCode.SPACE) {
						jump=false;
						character.setTranslateY(0);
						Timeline timeline =new Timeline();
						KeyValue keyvalue =new KeyValue(character.translateYProperty(),-90);
						KeyFrame keyFrame =new KeyFrame(
								Duration.millis(375),
								new EventHandler<ActionEvent>() {
									@Override
									public void handle(ActionEvent event) {
										Timeline timeline1 =new Timeline();
										KeyValue keyvalue1 =new KeyValue(character.translateYProperty(),0);
										KeyFrame keyFrame1 =new KeyFrame(Duration.millis(300),
												new EventHandler<ActionEvent>() {
											@Override
											public void handle(ActionEvent event) {
												jump=true;
											}
										},keyvalue1);
										timeline1.getKeyFrames().add(keyFrame1);
										timeline1.play();
									}
								},keyvalue);
						timeline.getKeyFrames().add(keyFrame);
						timeline.play();

					}
				}}
		});
	}










	//여기서부터 메소드들 선언부


	void imgMove(ImageView a ,int d) {
		if (stop_all) {
			a.setTranslateX(71);	//a이미지를 X71에 배치
			Timeline landtime =new Timeline();
			KeyValue landValue =new KeyValue(a.translateXProperty(),-400);	//a이미지를 x기준으로 -400이동
			KeyFrame landFrame =new KeyFrame(
					Duration.millis(1750-speed),	//속도 3000 -> 1750수정함 by.이건남	<- 수정해서 땅의 delay 수정요함
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							a.setTranslateX(71);
							int c =(int)(Math.random()*10);	//땅모양 랜덤 부분
							int e=0;
							if(c<8) e=0;else if(c==8)e=1;else if(c==9)e=2;
							a.setImage(new Image(getClass().getResource(landimg[e]).toString()));
							imgMove(a,0);
						}

					},landValue);

			landtime.getKeyFrames().add(landFrame);
			landtime.setDelay(Duration.millis(d*250));
			landtime.play();
			//멈추는 부분
		}}

	void cactMove() {
		if (stop_all) {

			cact.setTranslateX(50);
			cactRan = (int)(Math.random()*2)+1;
			if(cactRan==1) {
				cact.setFitWidth(30);
				cact.setFitHeight(40);
				cact.setLayoutY(105);	
				cact.setImage(new Image(getClass().getResource(cac[1]).toString()));
			}else if(cactRan==2) {
				cact.setFitWidth(50);
				cact.setFitHeight(30);
				cact.setLayoutY(115);
				cact.setImage(new Image(getClass().getResource(cac[2]).toString()));
			}
			Timeline cactTime =new Timeline();
			KeyValue cactValue =new KeyValue(cact.translateXProperty(),-460);	//이미지를 x기준으로 -400이동
			KeyFrame cactFrame =new KeyFrame(
					Duration.millis(1750-speed),	//속도 3000 -> 1750수정함 by.이건남	<- 수정해서 땅의 delay 수정요함
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							cactRan = (int)(Math.random()*2)+1;
							if(cactRan==1) {
								cact.setFitWidth(30);
								cact.setFitHeight(40);
								cact.setLayoutY(105);
								cact.setImage(new Image(getClass().getResource(cac[1]).toString()));
							}else if(cactRan==2) {
								cact.setFitWidth(50);
								cact.setFitHeight(30);
								cact.setLayoutY(115);
								cact.setImage(new Image(getClass().getResource(cac[2]).toString()));
							}
							cactMove();
						}
					},cactValue);
			cactTime.getKeyFrames().add(cactFrame);
			cactTime.play();
		}}







	void CharRun(ImageView character) {
		Timeline timeline =new Timeline();
		KeyValue keyvalue =new KeyValue(character.translateXProperty(),0);
		KeyFrame keyFrame =new KeyFrame(
				Duration.millis(75),
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						if (jump) {
							charrun++;if(charrun>2)charrun=0;
							character.setImage(new Image(getClass().getResource(charimg[charrun]).toString()));
							CharRun(character);
						}else {
							character.setImage(new Image(getClass().getResource(charimg[2]).toString()));
						CharRun(character);}
						
					}
				},keyvalue);
		timeline.getKeyFrames().add(keyFrame);
		timeline.play();

	}

	void score() {
		reco=0;
		while (stop_all) {
			try {Thread.sleep(100);} catch (InterruptedException e) {}
			reco++;
			if(reco<=500)speed=reco*2;

			//score==점수 ㅇㅋ?
			score.setText(Integer.toString(reco));
		}		
	}

	
	void collision() {
		while(stop_all) {
			/*선인장 부분*/
			//cactus X좌표값 불러오는 부분
			double c_x = cact.getLayoutX();
			double c_x_m = cact.getTranslateX();
			//cactus Y좌표값 불러오는 부분
			double c_y = cact.getLayoutY();
			double c_y_m = cact.getTranslateY();
			//cactus 현재 X,Y좌표값 구하는 부분
			double c_lowerLeft_x = c_x + c_x_m;
			double c_lowerLeft_y = c_y + c_y_m;
			double c_lower1_hit[][]= {{c_lowerLeft_x+10,c_lowerLeft_y},//오아충
					 {c_lowerLeft_x+20,c_lowerLeft_y},//왼아충
					 {c_lowerLeft_x,c_lowerLeft_y+10},//오아충
					 {c_lowerLeft_x+30,c_lowerLeft_y+10}}; //왼아충
			/*공룡 부분*/
			//character X좌표값 불러오는 부분
			double ch_x = character.getLayoutX();
			double ch_x_m = character.getTranslateX();
			
			//character Y좌표값 불러오는 부분
			double ch_y = character.getLayoutY();
			double ch_y_m = character.getTranslateY();
			//character 현재 X,Y좌표값 구하는 부분
			double ch_lowerLeft_x = ch_x + ch_x_m;
			double ch_lowerLeft_y = ch_y + ch_y_m;
			
			
			//			try {Thread.sleep(200);} catch (Exception e) {}
			//			System.out.println("공룡 : x =" + ch_lowerLeft_x + ", y=" + ch_lowerLeft_y);
			//			System.out.println("선인장 : x =" + c_lowerLeft_x + ", y=" + c_lowerLeft_y);
			           
			double ch_hit[][]= {{ch_lowerLeft_x+50,ch_lowerLeft_y+15},//왼위충
					{ch_lowerLeft_x+35,ch_lowerLeft_y+50},//왼위충
					{ch_lowerLeft_x+14,ch_lowerLeft_y+14},//오위충
					{ch_lowerLeft_x,ch_lowerLeft_y+30}};//오위충
			if (cactRan==1) {
				if((((ch_hit[0][0] >c_lower1_hit[0][0]&&ch_hit[0][1]>c_lower1_hit[0][1])&&
					(ch_hit[0][0] < c_lower1_hit[1][0]&&ch_hit[0][1]>c_lower1_hit[1][1]))||
					((ch_hit[0][0] > c_lower1_hit[2][0]&&ch_hit[0][1]>c_lower1_hit[2][1])&&
					(ch_hit[0][0] < c_lower1_hit[3][0]&&ch_hit[0][1]>c_lower1_hit[3][1]))||
					//========================0번포인트
					((ch_hit[1][0] > c_lower1_hit[0][0]&&ch_hit[1][1]>c_lower1_hit[0][1])&&
					(ch_hit[1][0] < c_lower1_hit[1][0]&&ch_hit[1][1]>c_lower1_hit[1][1]))||
					((ch_hit[1][0] > c_lower1_hit[2][0]&&ch_hit[1][1]>c_lower1_hit[2][1])&&
					(ch_hit[1][0] < c_lower1_hit[3][0]&&ch_hit[1][1]>c_lower1_hit[3][1]))||
					//========================1번포인트
					((ch_hit[2][0] > c_lower1_hit[0][0]&&ch_hit[2][1]>c_lower1_hit[0][1])&&
					(ch_hit[2][0] < c_lower1_hit[1][0]&&ch_hit[2][1]>c_lower1_hit[1][1]))||
					((ch_hit[2][0] > c_lower1_hit[2][0]&&ch_hit[2][1]>c_lower1_hit[2][1])&&
					(ch_hit[2][0] < c_lower1_hit[3][0]&&ch_hit[2][1]>c_lower1_hit[3][1]))||
					//========================2번포인트
					((ch_hit[3][0] > c_lower1_hit[0][0]&&ch_hit[2][1]>c_lower1_hit[0][1])&&
					(ch_hit[3][0] < c_lower1_hit[1][0]&&ch_hit[2][1]>c_lower1_hit[1][1]))||
					((ch_hit[3][0] > c_lower1_hit[2][0]&&ch_hit[2][1]>c_lower1_hit[2][1])&&
					(ch_hit[3][0] < c_lower1_hit[3][0]&&ch_hit[2][1]>c_lower1_hit[3][1]))
					//========================3번포인트
					)) {
				//1번 선인장일 때 죽은 경우
			
					//22,45 30,40 0.7
					stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)
					save.setOpacity(1);
					back.setOpacity(1);
					gameOver.setOpacity(1);
				}}else {
					if(		ch_lowerLeft_x < (c_lowerLeft_x + 50)
							&& (ch_lowerLeft_x + 50) > c_lowerLeft_x
							&& ch_lowerLeft_y < (c_lowerLeft_y + 30)
							&& (ch_lowerLeft_y + 50) > c_lowerLeft_y) {

						stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)
						save.setOpacity(1);
						back.setOpacity(1);
						gameOver.setOpacity(1);
					}
				}														
		}
	}



	void stop() {
		stop_all = false;
		//다 멈춤 stop all인데 모르면 바보 ㅇㅈ?
	}








	// 게임종료시 나오는 버튼 두개

	public void handleBackAction(MouseEvent event) {
		if (back.opacityProperty().getValue()==1) {

			try {
				Parent main = FXMLLoader.load(getClass().getResource("Main.fxml"));
				Scene scene = new Scene(main);
				Stage primaryStage = (Stage) back.getScene().getWindow();
				primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}}

	public void handleSaveAction(MouseEvent event) throws Exception{
		if (save.opacityProperty().getValue()==1) {
			dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			Stage primaryStage = (Stage)save.getScene().getWindow();
			dialog.initOwner(primaryStage);
			dialog.setTitle("기록 저장중");

			Parent parent = FXMLLoader.load(getClass().getResource("Save.fxml"));
			Scene scene = new Scene(parent);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
			save.setOpacity(0);
			back.setLayoutX(183);
		}}
}
