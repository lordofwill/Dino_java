package dinoGame;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class PvpController extends Main implements Initializable{
	@FXML private Text socketNumber;
	@FXML private ImageView PLAYER0_character;
	@FXML private ImageView PLAYER1_character;
	@FXML private ImageView PLAYER2_character;
	@FXML private ImageView PLAYER3_character;

	@FXML private ImageView PLAYER0_landA;
	@FXML private ImageView PLAYER0_landB;
	@FXML private ImageView PLAYER1_landA;
	@FXML private ImageView PLAYER1_landB;
	@FXML private ImageView PLAYER2_landA;
	@FXML private ImageView PLAYER2_landB;
	@FXML private ImageView PLAYER3_landA;
	@FXML private ImageView PLAYER3_landB;
	
	@FXML private ImageView PLAYER0_cactus;
	@FXML private ImageView PLAYER1_cactus;
	@FXML private ImageView PLAYER2_cactus;
	@FXML private ImageView PLAYER3_cactus;
	
	@FXML private ImageView PLAYER0_gameover;
	@FXML private ImageView PLAYER1_gameover;
	@FXML private ImageView PLAYER2_gameover;
	@FXML private ImageView PLAYER3_gameover;

	@FXML private TextField control;

	static boolean PLAYER0_life = true;
	static boolean PLAYER1_life = true;
	static boolean PLAYER2_life = true;
	static boolean PLAYER3_life = true;
	static int jumpSpeed = 400;
	static int charrun=0;


	static boolean jump = true;
	int cactRan;
	String [] cac = {"", "../data/cactus1.png", "../data/cactus2.png"};
	
	String [] characterImage = {"../data/main-character1.png","../data/main-character2.png","../data/main-character3.png","../data/main-character4.png"};








	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		socketNumber.setText(to);
		
		try {
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			int serverInput=dis.readInt(); 
			System.out.println(serverInput);
			} catch(Exception e) {}


		PLAYER0_landA.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER0_landA.setTranslateX(400);
		PLAYER1_landA.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER1_landA.setTranslateX(400);
		PLAYER2_landA.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER2_landA.setTranslateX(400);
		PLAYER3_landA.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER3_landA.setTranslateX(400);
		PLAYER0_landB.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER0_landB.setTranslateX(400);
		PLAYER1_landB.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER1_landB.setTranslateX(400);
		PLAYER2_landB.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER2_landB.setTranslateX(400);
		PLAYER3_landB.setImage(new Image(getClass().getResource("../data/newLand.png").toString())); PLAYER3_landB.setTranslateX(400);
		
			

			landMove(PLAYER0_landA, 0, PLAYER0_life);
			landMove(PLAYER0_landB, 1, PLAYER0_life);
			cactusMove(PLAYER0_cactus,PLAYER0_life,1);
			
			landMove(PLAYER1_landA, 0, PLAYER1_life);
			landMove(PLAYER1_landB, 1, PLAYER1_life);
			cactusMove(PLAYER1_cactus,PLAYER1_life,1);
			
			landMove(PLAYER2_landA, 0, PLAYER2_life);
			landMove(PLAYER2_landB, 1, PLAYER2_life);
			cactusMove(PLAYER2_cactus,PLAYER2_life,1);
			
			landMove(PLAYER3_landA, 0, PLAYER3_life);
			landMove(PLAYER3_landB, 1, PLAYER3_life);
			cactusMove(PLAYER3_cactus,PLAYER3_life,1);
			
		


		control.setOnKeyPressed(new EventHandler<KeyEvent>() {public void handle(KeyEvent event) {PLAYER0_jump(event);}});
		
		Thread t1 = new Thread(()->ENEMY_Jump());
		t1.start();
		Thread t2 = new Thread(()->collision());
		t2.start();
		Thread t3 = new Thread(()->{
			while(true) {
			PLAYER0_character.setImage(new Image(getClass().getResource("../data/main-character1.png").toString()));
			PLAYER1_character.setImage(new Image(getClass().getResource("../data/main-character1.png").toString()));
			PLAYER2_character.setImage(new Image(getClass().getResource("../data/main-character1.png").toString()));
			PLAYER3_character.setImage(new Image(getClass().getResource("../data/main-character1.png").toString()));
			try {Thread.sleep(70);} catch (InterruptedException e) {}
			PLAYER0_character.setImage(new Image(getClass().getResource("../data/main-character2.png").toString()));
			PLAYER1_character.setImage(new Image(getClass().getResource("../data/main-character2.png").toString()));
			PLAYER2_character.setImage(new Image(getClass().getResource("../data/main-character2.png").toString()));
			PLAYER3_character.setImage(new Image(getClass().getResource("../data/main-character2.png").toString()));
			try {Thread.sleep(70);} catch (InterruptedException e) {}
			}
			});
		t3.start();
		
	}



















	//여기서부터 메소드 선언부

	//플레이어0 점프
	void PLAYER0_jump(KeyEvent event) {
		if (jump) {
			if (event.getCode()==KeyCode.UP||event.getCode()==KeyCode.SPACE) {
				try {
					OutputStream os = socket.getOutputStream();
					DataOutputStream dos = new DataOutputStream(os);
					dos.writeInt(20);		// 점프시 서버에 20이라는 값을 보냅니다.
					System.out.println("서버로 20을 보냄.");   // 이부분에서 서버에 true값을 전달합니다.
					
					} catch(Exception e) {}
				
				
				jump=false;
				PLAYER0_character.setTranslateY(0);
				Timeline timeline =new Timeline();
				KeyValue keyvalue =new KeyValue(PLAYER0_character.translateYProperty(),-90);
				KeyFrame keyFrame =new KeyFrame(
						Duration.millis(jumpSpeed),
						new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent event) {
								Timeline timeline1 =new Timeline();
								KeyValue keyvalue1 =new KeyValue(PLAYER0_character.translateYProperty(),0);
								KeyFrame keyFrame1 =new KeyFrame(Duration.millis(jumpSpeed),
										new EventHandler<ActionEvent>() {
									@Override
									public void handle(ActionEvent event) {
										jump=true;
									}
								},keyvalue1);
								timeline1.getKeyFrames().add(keyFrame1);
								timeline1.play();
							}
						},keyvalue);
				timeline.getKeyFrames().add(keyFrame);
				timeline.play();
			}
		}
	}
	
	
	void ENEMY_Jump() {
		try {
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is);

			while(true) {
			int serverInput=dis.readInt(); 
			int serverjump = serverInput-myNumber;		
			int serverDeath = serverInput-myNumber;
			if(serverjump<0) {serverjump+=4;}  // 서버에서 입력값받음
			if(serverDeath<10) {serverDeath+=4;}
			
			
			
				
				if(serverjump==3) {
					Timeline timeline =new Timeline();
					KeyValue keyvalue =new KeyValue(PLAYER1_character.translateYProperty(),-90);
					KeyFrame keyFrame =new KeyFrame(
							Duration.millis(jumpSpeed),
							new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									Timeline timeline1 =new Timeline();
									KeyValue keyvalue1 =new KeyValue(PLAYER1_character.translateYProperty(),0);
									KeyFrame keyFrame1 =new KeyFrame(Duration.millis(jumpSpeed),
											new EventHandler<ActionEvent>() {
										@Override
										public void handle(ActionEvent event) {
											jump=true;
										}
									},keyvalue1);
									timeline1.getKeyFrames().add(keyFrame1);
									timeline1.play();
								}
							},keyvalue);
					timeline.getKeyFrames().add(keyFrame);
					timeline.play();
					serverInput=100;}
				
				
				else if(serverjump==2) {
					Timeline timeline =new Timeline();
					KeyValue keyvalue =new KeyValue(PLAYER2_character.translateYProperty(),-90);
					KeyFrame keyFrame =new KeyFrame(
							Duration.millis(jumpSpeed),
							new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									Timeline timeline1 =new Timeline();
									KeyValue keyvalue1 =new KeyValue(PLAYER2_character.translateYProperty(),0);
									KeyFrame keyFrame1 =new KeyFrame(Duration.millis(jumpSpeed),
											new EventHandler<ActionEvent>() {
										@Override
										public void handle(ActionEvent event) {
											jump=true;
										}
									},keyvalue1);
									timeline1.getKeyFrames().add(keyFrame1);
									timeline1.play();
								}
							},keyvalue);
					timeline.getKeyFrames().add(keyFrame);
					timeline.play();
					serverInput=100;
				} 
				
				
				else if(serverjump==1) {
					Timeline timeline =new Timeline();
					KeyValue keyvalue =new KeyValue(PLAYER3_character.translateYProperty(),-90);
					KeyFrame keyFrame =new KeyFrame(
							Duration.millis(jumpSpeed),
							new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									Timeline timeline1 =new Timeline();
									KeyValue keyvalue1 =new KeyValue(PLAYER3_character.translateYProperty(),0);
									KeyFrame keyFrame1 =new KeyFrame(Duration.millis(jumpSpeed),
											new EventHandler<ActionEvent>() {
										@Override
										public void handle(ActionEvent event) {
											jump=true;
										}
									},keyvalue1);
									timeline1.getKeyFrames().add(keyFrame1);
									timeline1.play();
								}
							},keyvalue);
					timeline.getKeyFrames().add(keyFrame);
					timeline.play();
					serverInput=100;
				}
				
				else if(serverDeath==13) {
					PLAYER1_character.setOpacity(0);
					PLAYER1_gameover.setOpacity(1);
					deathPLAYER1();
					
				}
				else if(serverDeath==12) {
					PLAYER2_character.setOpacity(0);
					PLAYER2_gameover.setOpacity(1);
					deathPLAYER2();
				}
				else if(serverDeath==11) {
					PLAYER3_character.setOpacity(0);
					PLAYER3_gameover.setOpacity(1);
					deathPLAYER3();
				}
				
				
				
				
				
			}
			
			
			
			} catch(Exception e) {}

	}
	
	
	void collision() {
		while(PLAYER0_life) {
			/*선인장 부분*/
			//cactus X좌표값 불러오는 부분
			double c_x = PLAYER0_cactus.getLayoutX();
			double c_x_m = PLAYER0_cactus.getTranslateX();
			//cactus Y좌표값 불러오는 부분
			double c_y = PLAYER0_cactus.getLayoutY();
			double c_y_m = PLAYER0_cactus.getTranslateY();
			//cactus 현재 X,Y좌표값 구하는 부분
			double c_lowerLeft_x = c_x + c_x_m;
			double c_lowerLeft_y = c_y + c_y_m;
			double c_lower1_hit[][]= {{c_lowerLeft_x+10,c_lowerLeft_y},//오아충
					 {c_lowerLeft_x+20,c_lowerLeft_y},//왼아충
					 {c_lowerLeft_x,c_lowerLeft_y+10},//오아충
					 {c_lowerLeft_x+30,c_lowerLeft_y+10}}; //왼아충

			/*공룡 부분*/
			//character X좌표값 불러오는 부분
			double ch_x = PLAYER0_character.getLayoutX();
			double ch_x_m = PLAYER0_character.getTranslateX();
			//cactus Y좌표값 불러오는 부분
			double ch_y = PLAYER0_character.getLayoutY();
			double ch_y_m = PLAYER0_character.getTranslateY();
			//cactus 현재 X,Y좌표값 구하는 부분
			double ch_lowerLeft_x = ch_x + ch_x_m;
			double ch_lowerLeft_y = ch_y + ch_y_m;

			//			try {Thread.sleep(200);} catch (Exception e) {}
			//			System.out.println("공룡 : x =" + ch_lowerLeft_x + ", y=" + ch_lowerLeft_y);
			//			System.out.println("선인장 : x =" + c_lowerLeft_x + ", y=" + c_lowerLeft_y);
			double ch_hit[][]= {{ch_lowerLeft_x+50,ch_lowerLeft_y+15},//왼위충
					{ch_lowerLeft_x+35,ch_lowerLeft_y+50},//왼위충
					{ch_lowerLeft_x+14,ch_lowerLeft_y+14},//오위충
					{ch_lowerLeft_x,ch_lowerLeft_y+30}};//오위충
			if (cactRan==1) {
				//1번 선인장일 때 죽은 경우
				if((((ch_hit[0][0] >c_lower1_hit[0][0]&&ch_hit[0][1]>c_lower1_hit[0][1])&&
						(ch_hit[0][0] < c_lower1_hit[1][0]&&ch_hit[0][1]>c_lower1_hit[1][1]))||
						((ch_hit[0][0] > c_lower1_hit[2][0]&&ch_hit[0][1]>c_lower1_hit[2][1])&&
						(ch_hit[0][0] < c_lower1_hit[3][0]&&ch_hit[0][1]>c_lower1_hit[3][1]))||
						//========================0번포인트
						((ch_hit[1][0] > c_lower1_hit[0][0]&&ch_hit[1][1]>c_lower1_hit[0][1])&&
						(ch_hit[1][0] < c_lower1_hit[1][0]&&ch_hit[1][1]>c_lower1_hit[1][1]))||
						((ch_hit[1][0] > c_lower1_hit[2][0]&&ch_hit[1][1]>c_lower1_hit[2][1])&&
						(ch_hit[1][0] < c_lower1_hit[3][0]&&ch_hit[1][1]>c_lower1_hit[3][1]))||
						//========================1번포인트
						((ch_hit[2][0] > c_lower1_hit[0][0]&&ch_hit[2][1]>c_lower1_hit[0][1])&&
						(ch_hit[2][0] < c_lower1_hit[1][0]&&ch_hit[2][1]>c_lower1_hit[1][1]))||
						((ch_hit[2][0] > c_lower1_hit[2][0]&&ch_hit[2][1]>c_lower1_hit[2][1])&&
						(ch_hit[2][0] < c_lower1_hit[3][0]&&ch_hit[2][1]>c_lower1_hit[3][1]))||
						//========================2번포인트
						((ch_hit[3][0] > c_lower1_hit[0][0]&&ch_hit[2][1]>c_lower1_hit[0][1])&&
						(ch_hit[3][0] < c_lower1_hit[1][0]&&ch_hit[2][1]>c_lower1_hit[1][1]))||
						((ch_hit[3][0] > c_lower1_hit[2][0]&&ch_hit[2][1]>c_lower1_hit[2][1])&&
						(ch_hit[3][0] < c_lower1_hit[3][0]&&ch_hit[2][1]>c_lower1_hit[3][1]))
						//========================3번포인트
						)) {

					deathPLAYER0();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)
					try {
						OutputStream os = socket.getOutputStream();
						DataOutputStream dos = new DataOutputStream(os);
						dos.writeInt(666);		// 점프시 서버에 20이라는 값을 보냅니다.
						System.out.println("서버로 666을 보냄.");   // 이부분에서 서버에 true값을 전달합니다.
						} catch(Exception e) {}
					PLAYER0_character.setOpacity(0);
					PLAYER0_gameover.setOpacity(1);
					
				}}else {
					if(ch_lowerLeft_x < (c_lowerLeft_x + 50)
							&& (ch_lowerLeft_x + 50) > c_lowerLeft_x
							&& ch_lowerLeft_y < (c_lowerLeft_y + 30)
							&& (ch_lowerLeft_y + 50) > c_lowerLeft_y) {

						deathPLAYER0();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)
						try {
							OutputStream os = socket.getOutputStream();
							DataOutputStream dos = new DataOutputStream(os);
							dos.writeInt(666);		// 점프시 서버에 20이라는 값을 보냅니다.
							System.out.println("서버로 666을 보냄.");   // 이부분에서 서버에 true값을 전달합니다.
							
							} catch(Exception e) {}
						PLAYER0_character.setOpacity(0);
						PLAYER0_gameover.setOpacity(1);
					}
				}														
		}
	}
	
	
	
	
	










	void landMove(ImageView a ,int d, boolean b) {
		if (b) {
			a.setTranslateX(400);	//a이미지를 X400에 배치
			Timeline landtime =new Timeline();
			KeyValue landValue =new KeyValue(a.translateXProperty(),-400);	//a이미지를 x기준으로 -400이동
			KeyFrame landFrame =new KeyFrame(
					Duration.millis(3000),	//속도 3000 -> 1750수정함 by.이건남	<- 수정해서 땅의 delay 수정요함
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							landMove(a,0,b);
						}

					},landValue);
			landtime.getKeyFrames().add(landFrame);
			landtime.setDelay(Duration.millis(d*1500));
			landtime.play();
		}}
	
	
	
	void cactusMove(ImageView a, boolean b,int d) {
		if (b) {
			a.setTranslateX(50);
			cactRan = (int)(Math.random()*2)+1;
			if(cactRan==1) {
				a.setFitWidth(30);
				a.setFitHeight(40);
				a.setLayoutY(105);	
				a.setImage(new Image(getClass().getResource(cac[1]).toString()));
			}else if(cactRan==2) {
				a.setFitWidth(50);
				a.setFitHeight(30);
				a.setLayoutY(115);
				a.setImage(new Image(getClass().getResource(cac[2]).toString()));
			}
			Timeline cactTime =new Timeline();
			KeyValue cactValue =new KeyValue(a.translateXProperty(),-460);	//이미지를 x기준으로 -400이동
			KeyFrame cactFrame =new KeyFrame(
					Duration.millis(1750),	//속도 3000 -> 1750수정함 by.이건남	<- 수정해서 땅의 delay 수정요함
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							a.setTranslateX(50);
							cactRan = (int)(Math.random()*2)+1;
							if(cactRan==1) {
								a.setFitWidth(30);
								a.setFitHeight(40);
								a.setLayoutY(105);
								a.setImage(new Image(getClass().getResource(cac[1]).toString()));
							}else if(cactRan==2) {
								a.setFitWidth(50);
								a.setFitHeight(30);
								a.setLayoutY(115);
								a.setImage(new Image(getClass().getResource(cac[2]).toString()));
							}
							if (!b) {
								cactTime.pause();
							}
							cactusMove(a,b,0);
						}
					},cactValue);
			cactTime.setDelay(Duration.millis(1000*d));
			cactTime.getKeyFrames().add(cactFrame);
			cactTime.play();
		}}
	
	
	
	
	
	
	void deathPLAYER0() {
		PLAYER0_life=false;
	}
	void deathPLAYER1() {
		PLAYER1_life=false;
	}
	void deathPLAYER2() {
		PLAYER2_life=false;
	}
	void deathPLAYER3() {
		PLAYER3_life=false;
	}

}
