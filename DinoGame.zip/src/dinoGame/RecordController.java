package dinoGame;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RecordController implements Initializable{
	static int[] score = new int[100];
	@FXML private ImageView back;
	@FXML private Text record;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		String data=" ";
		try {
			FileInputStream fis;
			fis = new FileInputStream("C:/Users/user/Documents/Eclipse/Dino/data/record.txt");
			Reader reader = new InputStreamReader(fis);
			int readByteNo;
			char[] readBytes = new char[3000];
			try {while((readByteNo=reader.read(readBytes))!=-1) {
					data = new String(readBytes, 0, readByteNo);}
			} catch (IOException e) {}
			} catch (FileNotFoundException e) {}
		System.out.println(data);
		
		String ranking[] = new String[100];				// ranking 배열은 홀수인덱스에 이름, 짝수인덱스에 점수가 들어감
		ranking = data.split("-");			
		System.out.println("랭킹의 배열 길이 :"+ranking.length);
		
		
		int[] set = new int[(ranking.length-1)/2+1];	// set[] 배열은 짝수인덱스의 개수+1 만큼 크기를 갖는다.
		
		for(int i=2; i<=ranking.length; i=i+2) {		// 짝수인덱스의 모든 점수들을 score[짝수] 배열에 int로 변환해서 넣음
			score[i]=Integer.parseInt(ranking[i]);
		}
		
		for(int i=1; i*2<ranking.length; i++) {			// 들어있는 짝수인덱스의 개수만큼 set[] 배열에 1을 채워줌
			set[i]=1;
		}
		
		
		for(int i=2; i<=ranking.length; i=i+2) {
			for(int j=2; j<=ranking.length; j=j+2) {
				if(score[i]==score[j]) {score[i]--;}
				if(score[i]<score[j]) {
					set[i/2]++;
				}
			}
		}												// set배열은 2,4,6,8,10 ... 번째 score배열의 크기를 비교해서, 높을수록 낮은 넘버를 매김.
		
		System.out.println(set.length);
		
		System.out.println("순위 나열");
		
		int[] index = new int[set.length];
		for(int i=1; i<set.length; i++) {
			index[set[i]]=i;
		}
		
		data="순위\t\t아이디\t\tScore\n\n";
		for(int i=1; i<6; i++) {
			int num = 2*index[i];
			data+=i+"\t\t"+ranking[num-1]+"\t\t"+ranking[num]+"점\n";
		}
		
		
		record.setText(data);
		back.setOnMouseClicked(event->handleBackAction(event));		
	}
	
	public void handleBackAction(MouseEvent event) {				
		try {
			Parent main = FXMLLoader.load(getClass().getResource("Main.fxml"));
			Scene scene = new Scene(main);
			Stage primaryStage = (Stage) back.getScene().getWindow();
			primaryStage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
