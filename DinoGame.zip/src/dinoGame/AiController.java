package dinoGame;

import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import javax.print.attribute.standard.Severity;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class AiController implements Initializable {

	@FXML private ImageView land0;
	@FXML private ImageView land1;
	@FXML private ImageView land2;
	@FXML private ImageView land3;
	@FXML private ImageView land4;
	@FXML private ImageView land5;
	@FXML private ImageView land6;
	@FXML private ImageView character;
	@FXML private ImageView cact;
	@FXML private ImageView cact1;//임시
	@FXML private TextField control;
	@FXML private Text score;
	@FXML private ImageView back;
	@FXML private ImageView save;
	@FXML private ImageView gameOver;
	@FXML private Text help1;
	@FXML private Text help2;
	public static int score1;
	int cactRan;
	boolean start=true;
	boolean stop_all = true;
	boolean jump = true;
	boolean aiJump = false;
	String [] charimg = {"../data/main-character1.png","../data/main-character2.png","../data/main-character3.png","../data/main-character4.png"};
	String [] landimg = {"../data/land2.png","../data/land1.png","../data/land3.png"};
	String [] cac = {"", "../data/cactus1.png", "../data/cactus2.png"};
	static Stage dialog;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		back.setOnMouseClicked(event->handleBackAction(event));		//뒤로가기
		save.setOnMouseClicked(event->{		//저장버튼
			try {
				handleSaveAction(event);
			} catch (Exception e) {
				e.printStackTrace();
			} 
		});
		character.setImage(new Image(getClass().getResource(charimg[1]).toString()));
		control.setTranslateY(-30);
		land0.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land1.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land2.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land3.setImage(new Image(getClass().getResource("../data/land2.png").toString()));
		land4.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land5.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land6.setImage(new Image(getClass().getResource("../data/land1.png").toString()));

		land0.setTranslateX(71);
		land1.setTranslateX(71);
		land2.setTranslateX(71);
		land3.setTranslateX(71);
		land4.setTranslateX(71);
		land5.setTranslateX(71);
		land6.setTranslateX(71);


		//실험용 cact1(센서)
		cact1.setImage(new Image(getClass().getResource("../data/cactus1.png").toString()));



		character.setOnMouseClicked(new EventHandler<Event>() {
			@Override
			public void handle(Event event) {
				if (start) {
					//land 움직임 부분
					imgMove(land0, 0);
					imgMove(land1, 1);
					imgMove(land2, 2);
					imgMove(land3, 3);
					imgMove(land4, 4);
					imgMove(land5, 5);
					imgMove(land6, 6);
					//cactus 움직임 부분
					cactMove();

					Thread t1 = new Thread(()->CharRun());;		//공룡 움직임 Thread
					Thread t2 = new Thread(()->cactMove());;	//선인장 움직임 Thread
					Thread t3 = new Thread(()->score());;		//점수  Thread
					Thread t4 = new Thread(()->collision());;	//충돌감지 Thread
					t1.start();
					t2.start();
					t3.start();
					t4.start();	
				}start=false;
				help1.setOpacity(0);
				help2.setOpacity(0);
			}

		});
		//Jump 부분
		control.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (aiJump == true) {	//<-조건문의 조건을 임의의 상자A와 선인장이 만나면 뛸 수 있도록
					System.out.println("뛰어주라");
					jump=false;
					character.setTranslateY(0);
					Timeline timeline =new Timeline();
					KeyValue keyvalue =new KeyValue(character.translateYProperty(),-90);
					KeyFrame keyFrame =new KeyFrame(
							Duration.millis(400),
							new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									Timeline timeline1 =new Timeline();
									KeyValue keyvalue1 =new KeyValue(character.translateYProperty(),0);
									KeyFrame keyFrame1 =new KeyFrame(Duration.millis(400),
											new EventHandler<ActionEvent>() {
										@Override
										public void handle(ActionEvent event) {
											jump=true;
										}
									},keyvalue1);
									timeline1.getKeyFrames().add(keyFrame1);
									timeline1.play();
								}
							},keyvalue);
					timeline.getKeyFrames().add(keyFrame);
					timeline.play();

				}
			}
		});
	}

	//땅
	void imgMove(ImageView a ,int d) {
		if (stop_all) {
			a.setTranslateX(71);
			Timeline landtime =new Timeline();
			KeyValue landValue =new KeyValue(a.translateXProperty(),-400);
			KeyFrame landFrame =new KeyFrame(
					Duration.millis(1750),
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							a.setTranslateX(71);
							int c =(int)(Math.random()*10);
							int e=0;
							if(c<8) e=0;else if(c==8)e=1;else if(c==9)e=2;
							a.setImage(new Image(getClass().getResource(landimg[e]).toString()));
							imgMove(a,0);
						}
					},landValue);
			landtime.getKeyFrames().add(landFrame);
			landtime.setDelay(Duration.millis(d*250));
			landtime.play();
		}}

	//선인장
	void cactMove() {
		if (stop_all) {
			//처음에 나오는 선인장 소스
			cact.setTranslateX(0);
			cactRan = (int)(Math.random()*2)+1;
			if(cactRan==1) {
				cact.setFitWidth(30);
				cact.setFitHeight(40);
				cact.setLayoutY(105);	
				cact.setImage(new Image(getClass().getResource(cac[1]).toString()));
			}else if(cactRan==2) {
				cact.setFitWidth(50);
				cact.setFitHeight(30);
				cact.setLayoutY(115);
				cact.setImage(new Image(getClass().getResource(cac[2]).toString()));
			}
			Timeline cactTime =new Timeline();
			KeyValue cactValue =new KeyValue(cact.translateXProperty(),-460);
			KeyFrame cactFrame =new KeyFrame(
					Duration.millis(1750),
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							//지속적으로 나오는 선인장 소스
							cact.setTranslateX(50);
							cactRan = (int)(Math.random()*2)+1;
							if(cactRan==1) {
								cact.setFitWidth(30);
								cact.setFitHeight(40);
								cact.setLayoutY(105);
								cact.setImage(new Image(getClass().getResource(cac[1]).toString()));
							}else if(cactRan==2) {
								cact.setFitWidth(50);
								cact.setFitHeight(30);
								cact.setLayoutY(115);
								cact.setImage(new Image(getClass().getResource(cac[2]).toString()));
							}
							cactMove();
						}
					},cactValue);
			cactTime.getKeyFrames().add(cactFrame);
			cactTime.play();
		}}

	void CharRun() {
		int i=0;
		while(stop_all){	//공룡이 점프하는 소스
			if(!jump) {
				character.setImage(new Image(getClass().getResource(charimg[2]).toString()));	//jump가 사용되면 이미지a[2]로 고정
				try {Thread.sleep(100);} catch (InterruptedException e) {}}
			i++;
			if (i>1){i=0;}
			try {Thread.sleep(70);} catch (Exception e) {}
			character.setImage(new Image(getClass().getResource(charimg[i]).toString()));
		}
		//부다치면 눈깔뒤집힘
		character.setImage(new Image(getClass().getResource(charimg[3]).toString()));	
	}

	void score() {
		//시작시 시간값을 받아옴
		Calendar start =Calendar.getInstance();
		int ms=start.get(Calendar.MINUTE);
		int ss=start.get(Calendar.SECOND);
		int miles=start.get(Calendar.MILLISECOND);
		//시간값을 계속 해서 바꿔줌 
		while (stop_all) {
			Calendar now =Calendar.getInstance();
			int m=now.get(Calendar.MINUTE);
			int s=now.get(Calendar.SECOND);
			int miless=now.get(Calendar.MILLISECOND);
			score1= (m-ms)*600+(s-ss)*10+(miless-miles)/100;
			//score==점수 ㅇㅋ?
			score.setText(Integer.toString(score1));
		}		
	}

	//충돌
	void collision() {
		while(stop_all) {
			/*선인장 부분*/
			//x
			double c_x = cact.getLayoutX();
			double c_x_m = cact.getTranslateX();
			//y
			double c_y = cact.getLayoutY();
			double c_y_m = cact.getTranslateY();
			//(x,y)
			double c_lowerLeft_x = c_x + c_x_m;
			double c_lowerLeft_y = c_y + c_y_m;

			/*공룡 부분*/
			//x
			double ch_x = character.getLayoutX();
			double ch_x_m = character.getTranslateX();
			//y
			double ch_y = character.getLayoutY();
			double ch_y_m = character.getTranslateY();
			//(x,y)
			double ch_lowerLeft_x = ch_x + ch_x_m;
			double ch_lowerLeft_y = ch_y + ch_y_m;

			//						try {Thread.sleep(200);} catch (Exception e) {});


			//장애물 감지하는 감지기 부분
			double s_x = cact1.getLayoutX();
			double s_y = cact1.getLayoutY();

				//감지되면 점프하는 소스
				if(s_x < (c_lowerLeft_x + 30)
						&& (s_x + 5) > c_lowerLeft_x
						&& s_y < (c_lowerLeft_y + 40)
						&& (s_y + 5) > c_lowerLeft_y) {
					int ai_ran = (int)(Math.random()*10)+1;
//					ai_ran = 10;
					
					if(ai_ran == 1) {
						//빨리뛰는 경우
						try {Thread.sleep(0);} catch (Exception e) {}
					}else if(ai_ran == 10) {
						//늦게뛰는 경우
						try {Thread.sleep(350);} catch (Exception e) {}
					}else {
						//정상적인 경우
						try {Thread.sleep(100);} catch (Exception e) {}
					}
					System.out.println(ai_ran);
					
					AiJump();
					aiJump = false;
					System.out.println("이젠 작작뛰어!!!!");
					try {Thread.sleep(150);} catch (Exception e) {}
				}
			

			if (cactRan==1) {
				//1번 선인장일 때 죽은 경우
				if(ch_lowerLeft_x < (c_lowerLeft_x + 30)
						&& (ch_lowerLeft_x + 50) > c_lowerLeft_x
						&& ch_lowerLeft_y < (c_lowerLeft_y + 40)
						&& (ch_lowerLeft_y + 50) > c_lowerLeft_y) {

					stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)
					save.setOpacity(1);
					back.setOpacity(1);
					gameOver.setOpacity(1);
				}}else {
					if(ch_lowerLeft_x < (c_lowerLeft_x + 50)
							&& (ch_lowerLeft_x + 50) > c_lowerLeft_x
							&& ch_lowerLeft_y < (c_lowerLeft_y + 30)
							&& (ch_lowerLeft_y + 50) > c_lowerLeft_y) {

						stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)
						save.setOpacity(1);
						back.setOpacity(1);
						gameOver.setOpacity(1);
					}
				}														
		}
	}


	void AiJump() {
		aiJump = true;	//센서가 감지되면 jump값을 true로 바꿔서 뛰게함

		if (aiJump == true) {	//<-조건문의 조건을 임의의 상자A와 선인장이 만나면 뛸 수 있도록
			System.out.println("뛰어주라");
			jump=false;
			character.setTranslateY(0);
			Timeline timeline =new Timeline();
			KeyValue keyvalue =new KeyValue(character.translateYProperty(),-90);
			KeyFrame keyFrame =new KeyFrame(
					Duration.millis(400),
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							Timeline timeline1 =new Timeline();
							KeyValue keyvalue1 =new KeyValue(character.translateYProperty(),0);
							KeyFrame keyFrame1 =new KeyFrame(Duration.millis(400),
									new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									jump=true;
								}
							},keyvalue1);
							timeline1.getKeyFrames().add(keyFrame1);
							timeline1.play();
						}
					},keyvalue);
			timeline.getKeyFrames().add(keyFrame);
			timeline.play();
		}
	}


	void stop() {
		stop_all = false;
		//다 멈춤 stop all인데 모르면 바보 ㅇㅈ?
	}
	public void handleBackAction(MouseEvent event) {
		if (back.opacityProperty().getValue()==1) {

			try {
				Parent main = FXMLLoader.load(getClass().getResource("Main.fxml"));
				Scene scene = new Scene(main);
				Stage primaryStage = (Stage) back.getScene().getWindow();
				primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}}

	public void handleSaveAction(MouseEvent event) throws Exception{
		if (save.opacityProperty().getValue()==1) {
			dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			Stage primaryStage = (Stage)save.getScene().getWindow();
			dialog.initOwner(primaryStage);
			dialog.setTitle("기록 저장중");

			Parent parent = FXMLLoader.load(getClass().getResource("Save.fxml"));
			Scene scene = new Scene(parent);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
			save.setOpacity(0);
			back.setLayoutX(183);
		}}
}
