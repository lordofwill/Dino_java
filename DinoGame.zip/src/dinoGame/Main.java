package dinoGame;

import java.net.Socket;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application{
	public static Socket socket;
	public static int myNumber;
	public static String to="123";
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("공룡게임 2.0");
		Parent root = FXMLLoader.load(Main.class.getResource("Main.fxml"));
		Scene scene = new Scene(root);
		
		primaryStage.setScene(scene);
		primaryStage.setResizable(false);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		
		try {Library.dataLoading();} catch (Exception e) {} // 랭킹 데이터를 읽어오는 Library클래스의 메소드 
		launch(args);
	}
	
}
