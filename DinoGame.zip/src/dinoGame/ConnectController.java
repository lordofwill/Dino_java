package dinoGame;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;

public class ConnectController implements Initializable{
	@FXML public static Text message;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Socket socket = null;
		socket = new Socket();
		System.out.println("서버에 연결을 요청합니다...");
		try {
			socket.connect(new InetSocketAddress("10.10.21.127",8080));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("서버에 연결 성공.");
		MainController.connectDialog.close();
		
		
		
	}

}
