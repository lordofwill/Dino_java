package dinoGame;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class AiModeTestController implements Initializable {

	@FXML private ImageView land0;
	@FXML private ImageView land1;
	@FXML private ImageView land2;
	@FXML private ImageView land3;
	@FXML private ImageView land4;
	@FXML private ImageView land5;
	@FXML private ImageView land6;
	@FXML private ImageView character;
	@FXML private ImageView cact;
	@FXML private TextField control;
	@FXML private Text score;
	@FXML private ImageView back;
	@FXML private ImageView save;
	@FXML private ImageView gameOver;
	@FXML private Text help1;
	@FXML private Text help2;

	@FXML private ImageView ai_land0;
	@FXML private ImageView ai_land1;
	@FXML private ImageView ai_land2;
	@FXML private ImageView ai_land3;
	@FXML private ImageView ai_land4;
	@FXML private ImageView ai_land5;
	@FXML private ImageView ai_land6;
	@FXML private ImageView ai_character;
	@FXML private ImageView ai_cact;
	@FXML private ImageView ai_back;
	@FXML private ImageView ai_save;
	@FXML private ImageView ai_gameOver;
	@FXML private Text ai_help1;
	@FXML private Text ai_help2;
	@FXML private Text playerWin;
	@FXML private Text playerLose;



	boolean aiJump = false;
	public static int score1;

	int cactRan;
	boolean result = true;
	boolean start=true;
	boolean stop_all = true;
	boolean jump = true;
	boolean ai_jump = true;
	boolean jumpAi = true;
	String [] charimg = {"../data/main-character1.png","../data/main-character2.png","../data/main-character3.png","../data/main-character4.png"};
	String [] ai_charimg = {"../data/ai-character1.png","../data/ai-character2.png","../data/ai-character3.png","../data/ai-character4.png"};
	String [] landimg = {"../data/land2.png","../data/land1.png","../data/land3.png"};
	String [] cac = {"", "../data/cactus1.png", "../data/cactus2.png"};
	static Stage dialog;

	//AI
	static double s_x;
	static double s_y;
	static double ai_c_lowerLeft_x;
	static double ai_c_lowerLeft_y;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		back.setOnMouseClicked(event->handleBackAction(event));//뒤로가기 등록

		character.setImage(new Image(getClass().getResource(charimg[1]).toString()));
		control.setTranslateY(-30);
		land0.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land1.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land2.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land3.setImage(new Image(getClass().getResource("../data/land2.png").toString()));
		land4.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land5.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		land6.setImage(new Image(getClass().getResource("../data/land1.png").toString()));

		land0.setTranslateX(71);
		land1.setTranslateX(71);
		land2.setTranslateX(71);
		land3.setTranslateX(71);
		land4.setTranslateX(71);
		land5.setTranslateX(71);
		land6.setTranslateX(71);


		ai_character.setImage(new Image(getClass().getResource(ai_charimg[1]).toString()));
		ai_land0.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		ai_land1.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		ai_land2.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		ai_land3.setImage(new Image(getClass().getResource("../data/land2.png").toString()));
		ai_land4.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		ai_land5.setImage(new Image(getClass().getResource("../data/land1.png").toString()));
		ai_land6.setImage(new Image(getClass().getResource("../data/land1.png").toString()));

		ai_land0.setTranslateX(71);
		ai_land1.setTranslateX(71);
		ai_land2.setTranslateX(71);
		ai_land3.setTranslateX(71);
		ai_land4.setTranslateX(71);
		ai_land5.setTranslateX(71);
		ai_land6.setTranslateX(71);






		character.setOnMouseClicked(new EventHandler<Event>(){
			@Override
			public void handle(Event event) {
				if (start) {
					//PLAYER-land 움직임 부분
					imgMove(land0, 0);
					imgMove(land1, 1);
					imgMove(land2, 2);
					imgMove(land3, 3);
					imgMove(land4, 4);
					imgMove(land5, 5);
					imgMove(land6, 6);

					cactMove(cact);

					Thread t1 = new Thread(()->CharRun(character));;			//Player 움직임 Thread
					Thread t4 = new Thread(()->collision(character,cact));;		//Player 충돌 감지 Thread
					t1.start();
					t4.start();	

					help1.setOpacity(0);
					help2.setOpacity(0);


					//AI-land 움직임 부분
					imgMove(ai_land0, 0);
					imgMove(ai_land1, 1);
					imgMove(ai_land2, 2);
					imgMove(ai_land3, 3);
					imgMove(ai_land4, 4);
					imgMove(ai_land5, 5);
					imgMove(ai_land6, 6);

					cactMove(ai_cact);

					Thread a1 = new Thread(()->ai_CharRun(ai_character));;				//AI공룡 움직임 Thread
					Thread a4 = new Thread(()->ai_collision(ai_character,ai_cact));;	//AI충돌감지 Thread
					a1.start();
					a4.start();	

					//수정 요함 a5
					Thread a5 = new Thread(()-> {										//AI센서 Thread	
						while(stop_all) {
							try {Thread.sleep(20);} catch (Exception e) {}

							if(s_x < (ai_c_lowerLeft_x + 30)
									&& (s_x + 5) > ai_c_lowerLeft_x
									&& s_y < (ai_c_lowerLeft_y + 40)
									&& (s_y + 5) > ai_c_lowerLeft_y
									&& stop_all == true) {

								AiJump();
								aiJump = false;
								try {Thread.sleep(150);} catch (Exception e) {}
							}
						}});
					a5.start();	

				}start=false;

				ai_help1.setOpacity(0);
				ai_help2.setOpacity(0);	
			}

		});



		//=================player-Jump 부분======================
		control.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (jump) {
					if (event.getCode()==KeyCode.UP||event.getCode()==KeyCode.SPACE) {
						jump=false;
						character.setTranslateY(0);
						Timeline timeline =new Timeline();
						KeyValue keyvalue =new KeyValue(character.translateYProperty(),-90);
						KeyFrame keyFrame =new KeyFrame(
								Duration.millis(400),
								new EventHandler<ActionEvent>() {
									@Override
									public void handle(ActionEvent event) {
										Timeline timeline1 =new Timeline();
										KeyValue keyvalue1 =new KeyValue(character.translateYProperty(),0);
										KeyFrame keyFrame1 =new KeyFrame(Duration.millis(400),
												new EventHandler<ActionEvent>() {
											@Override
											public void handle(ActionEvent event) {
												jump=true;
											}
										},keyvalue1);
										timeline1.getKeyFrames().add(keyFrame1);
										timeline1.play();
									}
								},keyvalue);
						timeline.getKeyFrames().add(keyFrame);
						timeline.play();

					}
				}}
		});
	}



	//===================land 이동 메소드=========================
	void imgMove(ImageView lands ,int delay) {
		if (stop_all) {
			lands.setTranslateX(71);
			Timeline landtime =new Timeline();
			KeyValue landValue =new KeyValue(lands.translateXProperty(),-400);
			KeyFrame landFrame =new KeyFrame(
					Duration.millis(1750),
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							lands.setTranslateX(71);
							int c =(int)(Math.random()*10);
							int e=0;
							if(c<8) e=0;else if(c==8)e=1;else if(c==9)e=2;
							lands.setImage(new Image(getClass().getResource(landimg[e]).toString()));
							imgMove(lands,0);
						}

					},landValue);

			landtime.getKeyFrames().add(landFrame);
			landtime.setDelay(Duration.millis(delay*250));
			landtime.play();
		}}


	//===========cactus 이동 메소드=====================
	void cactMove(ImageView rancact) {//랜덤함수로 나오는 선인장에 따라 크기와 이미지를 선정 해 준다.
		if (stop_all) {
			rancact.setTranslateX(50);
			cactRan = (int)(Math.random()*2)+1;
			if(cactRan==1) {
				rancact.setFitWidth(30);
				rancact.setFitHeight(40);
				rancact.setLayoutY(105);	
				rancact.setImage(new Image(getClass().getResource(cac[1]).toString()));
			}else if(cactRan==2) {
				rancact.setFitWidth(50);
				rancact.setFitHeight(30);
				rancact.setLayoutY(115);
				rancact.setImage(new Image(getClass().getResource(cac[2]).toString()));
			}

			Timeline cactTime =new Timeline();
			KeyValue cactValue =new KeyValue(rancact.translateXProperty(),-460);
			KeyFrame cactFrame =new KeyFrame(
					Duration.millis(1750),
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							rancact.setTranslateX(50);
							cactRan = (int)(Math.random()*2)+1;
							if(cactRan==1) {
								rancact.setFitWidth(30);
								rancact.setFitHeight(40);
								rancact.setLayoutY(105);
								rancact.setImage(new Image(getClass().getResource(cac[1]).toString()));
							}else if(cactRan==2) {
								rancact.setFitWidth(50);
								rancact.setFitHeight(30);
								rancact.setLayoutY(115);
								rancact.setImage(new Image(getClass().getResource(cac[2]).toString()));
							}
							cactMove(rancact);
						}
					},cactValue);
			cactTime.getKeyFrames().add(cactFrame);
			cactTime.play();
			
			if(rancact == ai_cact) {
				collision_sub();//실험
			}
		}}


	//===========Player 움직임 부분===========
	void CharRun(ImageView Player) {
		int i=0;
		while(stop_all){
			if(!jump) {
				Player.setImage(new Image(getClass().getResource(charimg[2]).toString()));	//jump가 사용되면 이미지a[2]로 고정
				try {Thread.sleep(100);} catch (InterruptedException e) {}}
			i++;	//i를 사용해서 이미지를 바꿔줌
			if (i>1){i=0;}
			try {Thread.sleep(70);} catch (Exception e) {}
			Player.setImage(new Image(getClass().getResource(charimg[i]).toString()));
		}        
		//부다치면 눈깔뒤집힘
		Player.setImage(new Image(getClass().getResource(charimg[3]).toString()));	
	}

	//===========AI 움직임 부분===========
	void ai_CharRun(ImageView aiCharacter) {
		int ai=0;
		while(stop_all){
			if(!ai_jump) {
				aiCharacter.setImage(new Image(getClass().getResource(ai_charimg[2]).toString()));	//jump가 사용되면 이미지a[2]로 고정
				try {Thread.sleep(100);} catch (InterruptedException e) {}}
			ai++;	//i를 사용해서 이미지를 바꿔줌
			if (ai>1){ai=0;}
			try {Thread.sleep(70);} catch (Exception e) {}
			aiCharacter.setImage(new Image(getClass().getResource(ai_charimg[ai]).toString()));
		}
		//부다치면 눈깔뒤집힘
		aiCharacter.setImage(new Image(getClass().getResource(ai_charimg[3]).toString()));	
	}


	//===========Player 충돌 메소드===========
	void collision(ImageView chara,ImageView cactu) {
		while(stop_all) {
			/*선인장 부분*/
			//X
			double c_x = cactu.getLayoutX();
			double c_x_m = cactu.getTranslateX();
			//Y
			double c_y = cactu.getLayoutY();
			double c_y_m = cactu.getTranslateY();
			//(X,Y)
			double c_lowerLeft_x = c_x + c_x_m;
			double c_lowerLeft_y = c_y + c_y_m;

			/*공룡 부분*/
			//X
			double ch_x =  chara.getLayoutX();
			double ch_x_m =  chara.getTranslateX();
			//Y
			double ch_y =  chara.getLayoutY();
			double ch_y_m =  chara.getTranslateY();
			//(X,Y)
			double ch_lowerLeft_x = ch_x + ch_x_m;
			double ch_lowerLeft_y = ch_y + ch_y_m;


			if (cactRan==1) {
				//1번 선인장일 때 죽은 경우
				if(ch_lowerLeft_x < (c_lowerLeft_x + 30)
						&& (ch_lowerLeft_x + 50) > c_lowerLeft_x
						&& ch_lowerLeft_y < (c_lowerLeft_y + 40)
						&& (ch_lowerLeft_y + 50) > c_lowerLeft_y) {

					stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)

					if(result == true) {
						back.setOpacity(1);
						playerLose.setOpacity(1);	//player 충돌시 playerLose
						result = false;
					}

				}}else {
					if(ch_lowerLeft_x < (c_lowerLeft_x + 50)
							&& (ch_lowerLeft_x + 50) > c_lowerLeft_x
							&& ch_lowerLeft_y < (c_lowerLeft_y + 30)
							&& (ch_lowerLeft_y + 50) > c_lowerLeft_y) {

						stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)

						if(result == true) {
							back.setOpacity(1);
							playerLose.setOpacity(1);	//player 충돌시 playerLose
							result = false;
						}
					}
				}														
		}
	}

	//===========AI 충돌 메소드===========
	void ai_collision(ImageView chara,ImageView cactu) {
		while(stop_all) {
			/*선인장 부분*/
			//X
			double ai_c_x = cactu.getLayoutX();
			double ai_c_x_m = cactu.getTranslateX();
			//Y
			double ai_c_y = cactu.getLayoutY();
			double ai_c_y_m = cactu.getTranslateY();
			//(X,Y)
			ai_c_lowerLeft_x = ai_c_x + ai_c_x_m;
			ai_c_lowerLeft_y = ai_c_y + ai_c_y_m;

			/*공룡 부분*/
			//X
			double ai_ch_x =  chara.getLayoutX();
			double ai_ch_x_m =  chara.getTranslateX();
			//Y
			double ai_ch_y =  chara.getLayoutY();
			double ai_ch_y_m =  chara.getTranslateY();
			//(X,Y)
			double ai_ch_lowerLeft_x = ai_ch_x + ai_ch_x_m;
			double ai_ch_lowerLeft_y = ai_ch_y + ai_ch_y_m;


			if (cactRan==1) {
				//1번 선인장일 때 죽은 경우
				if(ai_ch_lowerLeft_x < (ai_c_lowerLeft_x + 30)
						&& (ai_ch_lowerLeft_x + 50) > ai_c_lowerLeft_x
						&& ai_ch_lowerLeft_y < (ai_c_lowerLeft_y + 40)
						&& (ai_ch_lowerLeft_y + 50) > ai_c_lowerLeft_y) {

					stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)

					if(result == true) {
						back.setOpacity(1);
						playerWin.setOpacity(1);	//ai 충돌시 playerWin
						result = false;
					}
				}}else {
					if(ai_ch_lowerLeft_x < (ai_c_lowerLeft_x + 50)
							&& (ai_ch_lowerLeft_x + 50) > ai_c_lowerLeft_x
							&& ai_ch_lowerLeft_y < (ai_c_lowerLeft_y + 30)
							&& (ai_ch_lowerLeft_y + 50) > ai_c_lowerLeft_y) {

						stop();	//멈추는 메소드 호출(눈 커지는 죽은 이미지는 움직임 부분에)

						if(result == true) {
							back.setOpacity(1);
							playerWin.setOpacity(1);	//ai 충돌시 playerWin
							result = false;
						}
					}
				}														
		}
	}

	//=================충돌하면 멈추는 메소드========================
	void stop() {
		stop_all = false;
		//다 멈춤 stop all인데 모르면 바보 ㅇㅈ?
	}


	//=========================AI-Jump=========================
	void AiJump() {
		aiJump = true;	//센서가 감지되면 jump값을 true로 바꿔서 뛰게함

		if (aiJump == true) {	//<-조건문의 조건을 임의의 상자A와 선인장이 만나면 뛸 수 있도록
			aiJump = false;
			System.out.println("뛰어주라");
			ai_jump=false;
			ai_character.setTranslateY(0);
			Timeline timeline =new Timeline();
			KeyValue keyvalue =new KeyValue(ai_character.translateYProperty(),-90);
			KeyFrame keyFrame =new KeyFrame(
					Duration.millis(400),
					new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							Timeline timeline1 =new Timeline();
							KeyValue keyvalue1 =new KeyValue(ai_character.translateYProperty(),0);
							KeyFrame keyFrame1 =new KeyFrame(Duration.millis(400),
									new EventHandler<ActionEvent>() {
								@Override
								public void handle(ActionEvent event) {
									ai_jump=true;
								}
							},keyvalue1);
							timeline1.getKeyFrames().add(keyFrame1);
							timeline1.play();
						}
					},keyvalue);
			timeline.getKeyFrames().add(keyFrame);
			timeline.play();
		}
	}

	//================ai 뛰는위치 정하는 부분================
	void collision_sub() {
		int ai_ran_cact = (int)(Math.random()*20)+1;
		s_y = 130;
//				ai_ran_cact =1;

		//장애물 감지하는 감지기 부분
		if(ai_ran_cact == 1) {
			s_x = 100;
		}else if(ai_ran_cact == 20) {
			s_x = 200;
		}else {
			s_x = 125;
		}

		System.out.println("랜덤 : " + ai_ran_cact);
	}


	//================뒤로가기 버튼================
	public void handleBackAction(MouseEvent event) {
		if (back.opacityProperty().getValue()==1) {
			try {
				Parent main = FXMLLoader.load(getClass().getResource("Main.fxml"));
				Scene scene = new Scene(main);
				Stage primaryStage = (Stage) back.getScene().getWindow();
				primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}}



}